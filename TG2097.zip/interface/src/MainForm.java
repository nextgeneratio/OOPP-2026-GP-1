import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainForm extends JFrame {

    private JTextField weightField;
    private JComboBox<String> weightUnitCombo;
    private JTextField heightField;
    private JComboBox<String> heightUnitCombo;
    private JButton calculateButton;
    private JLabel bmiScoreLabel;
    private JLabel bmiCategoryLabel;

    public MainForm() {
        setTitle("BMI CALCULATOR");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel container = new JPanel(new BorderLayout());
        container.setBorder(new EmptyBorder(30, 40, 30, 40));


        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 5));

        JLabel titleLabel = new JLabel("BMI Calculator", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));

        JLabel subTitleLabel = new JLabel("Check your body mass index health status", SwingConstants.CENTER);
        subTitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        headerPanel.add(titleLabel);
        headerPanel.add(subTitleLabel);
        container.add(headerPanel, BorderLayout.NORTH);


        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 0, 12, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 1.0; gbc.gridwidth = 2;
        JLabel wLabel = new JLabel("Weight");
        wLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        formPanel.add(wLabel, gbc);

        gbc.gridy = 1; gbc.gridwidth = 1; gbc.weightx = 0.7;
        weightField = new JTextField();
        styleTextField(weightField);
        formPanel.add(weightField, gbc);

        gbc.gridx = 1; gbc.weightx = 0.3;
        gbc.insets = new Insets(12, 10, 12, 0);
        weightUnitCombo = new JComboBox<>(new String[]{"kg", "pound"});
        weightUnitCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(weightUnitCombo, gbc);


        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 1.0; gbc.gridwidth = 2;
        gbc.insets = new Insets(12, 0, 12, 0);
        JLabel hLabel = new JLabel("Height");
        hLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        formPanel.add(hLabel, gbc);

        gbc.gridy = 3; gbc.gridwidth = 1; gbc.weightx = 0.7;
        heightField = new JTextField();
        styleTextField(heightField);
        formPanel.add(heightField, gbc);

        gbc.gridx = 1; gbc.weightx = 0.3;
        gbc.insets = new Insets(12, 10, 12, 0);
        heightUnitCombo = new JComboBox<>(new String[]{"m", "In"});
        heightUnitCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(heightUnitCombo, gbc);


        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.weightx = 1.0;
        gbc.insets = new Insets(25, 0, 10, 0);
        calculateButton = new JButton("Calculate BMI");
        calculateButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        calculateButton.setFocusPainted(false);
        calculateButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        formPanel.add(calculateButton, gbc);

        container.add(formPanel, BorderLayout.CENTER);


        JPanel bottomPanel = new JPanel(new BorderLayout(0, 10));

        JLabel resHeader = new JLabel("Result", SwingConstants.LEFT);
        resHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        bottomPanel.add(resHeader, BorderLayout.NORTH);

        JPanel resultCard = new JPanel(new GridLayout(1, 2, 15, 0));
        resultCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JPanel scoreBox = new JPanel(new GridLayout(2, 1));
        JLabel scoreTitle = new JLabel("BMI SCORE", SwingConstants.CENTER);
        scoreTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        bmiScoreLabel = new JLabel("--.-", SwingConstants.CENTER);
        bmiScoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        scoreBox.add(scoreTitle);
        scoreBox.add(bmiScoreLabel);

        JPanel categoryBox = new JPanel(new GridLayout(2, 1));
        JLabel catTitle = new JLabel("CATEGORY", SwingConstants.CENTER);
        catTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        bmiCategoryLabel = new JLabel("No Input", SwingConstants.CENTER);
        bmiCategoryLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        categoryBox.add(catTitle);
        categoryBox.add(bmiCategoryLabel);

        resultCard.add(scoreBox);
        resultCard.add(categoryBox);
        bottomPanel.add(resultCard, BorderLayout.CENTER);

        container.add(bottomPanel, BorderLayout.SOUTH);
        setContentPane(container);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateBMI();
            }
        });
    }

    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
    }

    private void calculateBMI() {
        try {
            double weight = Double.parseDouble(weightField.getText().trim());
            double height = Double.parseDouble(heightField.getText().trim());

            String weightUnit = (String) weightUnitCombo.getSelectedItem();
            String heightUnit = (String) heightUnitCombo.getSelectedItem();

            if ("pound".equalsIgnoreCase(weightUnit)) weight = weight * 0.45359237;
            if ("In".equalsIgnoreCase(heightUnit)) height = height * 0.0254;

            if (height <= 0) {
                JOptionPane.showMessageDialog(this, "Height must be greater than 0.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double bmi = weight / (height * height);
            bmiScoreLabel.setText(String.format("%.1f", bmi));

            String category;
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi < 25.0) {
                category = "Normal";
            } else if (bmi < 30.0) {
                category = "Overweight";
            } else {
                category = "Obese";
            }

            bmiCategoryLabel.setText(category);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainForm().setVisible(true));
    }
}
